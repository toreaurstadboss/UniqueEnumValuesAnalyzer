﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniqueEnumValueFixer.Test
{
    public enum SomeEnum
    {
        A = 1,
        B = 1 
    }
}
